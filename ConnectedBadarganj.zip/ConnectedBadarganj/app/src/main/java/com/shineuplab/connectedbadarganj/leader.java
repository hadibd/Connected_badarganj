package com.shineuplab.connectedbadarganj;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class leader extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leader);


    }


    public void Test1(View view) {
        Intent i = new Intent(getApplicationContext(), profile_person.class);
        startActivity(i);
    }
}
