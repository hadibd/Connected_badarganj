package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class govt_office extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_govt_office);

        ListView listView = findViewById(R.id.govt_employee_listView_id);
        TextView textView = findViewById(R.id.textView_leader_adapter);
        String [] listItem = getResources().getStringArray(R.array.govt_office);
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.leader_adapter, R.id.textView_leader_adapter, listItem);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position ==  0) {
                    Toast.makeText(govt_office.this, "Facebook Description", Toast.LENGTH_SHORT).show();
                }
                if (position ==  0) {
                    Toast.makeText(govt_office.this, "Whatsapp Description", Toast.LENGTH_SHORT).show();
                }
                if (position ==  0) {
                    Toast.makeText(govt_office.this, "Twitter Description", Toast.LENGTH_SHORT).show();
                }
                if (position ==  0) {
                    Toast.makeText(govt_office.this, "Instagram Description", Toast.LENGTH_SHORT).show();
                }
                if (position ==  0) {
                    Toast.makeText(govt_office.this, "Youtube Description", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
