package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class personality extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personality);
    }

    public void Test(View view) {
        Intent intent = new Intent(getApplicationContext(), profile_person.class);
        startActivity(intent);
    }

    public void Test1(View view) {
        Intent intent = new Intent(getApplicationContext(), train.class);
        startActivity(intent);
    }
}
