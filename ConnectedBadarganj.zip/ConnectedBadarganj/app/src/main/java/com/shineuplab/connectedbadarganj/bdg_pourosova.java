package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.LinearLayout;


public class bdg_pourosova extends AppCompatActivity {

    ImageView Pourobg;
    LinearLayout welcomeText, Menu;
    Animation frombottom;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bdg_pourosova);

        frombottom = AnimationUtils.loadAnimation(this, R.anim.frombottom);

        Pourobg = findViewById(R.id.bgImage);
        welcomeText = findViewById(R.id.welcomeTextId);
        Menu = findViewById(R.id.menuId);

        Pourobg.animate().translationY(-1500).setDuration(1500).setStartDelay(300);
        welcomeText.animate().translationY(-440).setDuration(1500).setStartDelay(300);

       // welcomeText.startAnimation(frombottom);
        Menu.startAnimation(frombottom);

    }
}
