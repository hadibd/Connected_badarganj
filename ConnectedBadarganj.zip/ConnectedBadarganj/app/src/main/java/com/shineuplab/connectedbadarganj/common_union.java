package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;

public class common_union extends AppCompatActivity {

    LinearLayout upMenu;
    Animation frombottom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common_union);

        upMenu = findViewById(R.id.upMenu);
        frombottom = AnimationUtils.loadAnimation(this, R.anim.frombottom);

        upMenu.startAnimation(frombottom);
    }
}
