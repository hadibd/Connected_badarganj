package com.shineuplab.connectedbadarganj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class doctor_chamber extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_chamber);
    }

    public void diagnostic_center(View view) {
        Intent intent = new Intent(getApplicationContext(), diagnostic_center.class);
        startActivity(intent);
    }
}
